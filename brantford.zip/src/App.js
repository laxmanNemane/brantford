import React, { Fragment } from "react";
import Routing from "./Navigation/Route";
// import Featurs from "./UserPanel/Featurs";

function App() {
  return (
    <Fragment>
      <Routing />
    </Fragment>
  );
}

export default App;
