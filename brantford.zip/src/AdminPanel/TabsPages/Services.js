

import React from 'react'

const Services = () => {
  return (
    <div className=" my-2 ms-2" style={{width:"99%"}}>
         <div className=" py-2">
          <h4 className="pt-2 me-auto">Service is Avialable</h4>
        </div>
    </div>
  )
}

export default Services