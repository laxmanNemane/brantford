import React from 'react'

const SearchProperties = () => {
  return (
    <div>
      
    </div>
  )
}

export default SearchProperties
